/**
  ******************************************************************************
  * @file    stm32f10x_adc.h
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    11-March-2011
  * @brief   This file contains all the functions prototypes for the ADC firmware 
  *          library.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __hardware_H
#define __hardware_H
#include "stm32f10x_gpio.h"







#define NULLPTR (void *)		0
#define TRUE					1
#define FALSE					0
#define SYSERR					(0)
#define SYSOK					1
#define NULL					0


#define SYSCALL					INT16


#define CALLBACK

//#define LOCAL					static

/*
 * Structures and Type Definitions
 */
typedef void * 					HANDLE;


// Unsigned Base Types
typedef unsigned char			BOOL;
typedef unsigned char 			BYTE;
typedef unsigned short int		WORD;
typedef unsigned long int		DWORD;


typedef unsigned char			UCHAR;
typedef unsigned short			USHORT;
typedef unsigned int			UINT;

typedef unsigned char  byte;    /* �޷����ֽڱ���*/
typedef unsigned short word;    /* �޷����ֱ���*/
typedef unsigned long  dword;   /* �޷���˫�ֱ���*/
typedef signed char    sbyte;   /* �з����ֽڱ���*/
typedef signed short   sword;   /* �з����ֱ���*/
typedef signed long    sdword;  /* �з���˫�ֱ���*/

typedef unsigned char *		LPSTR;
typedef unsigned short *	LPWORD;
// Signed Base Types
typedef signed char     		INT8;
typedef signed short    		INT16;
typedef signed long     		INT32;

typedef unsigned char   		UINT8;
typedef unsigned short  		UINT16;
typedef unsigned long   		UINT32;


typedef struct //
{
	UINT16  En;
	UINT16  Hz;
	UINT16  Cycle;
} gStructLed;



#define LED1ON  GPIO_ResetBits(GPIOB, GPIO_Pin_11);
#define LED1OFF GPIO_SetBits(GPIOB, GPIO_Pin_11);

//#define LED1ON  GPIO_ResetBits(GPIOC, GPIO_Pin_13);
//#define LED1OFF GPIO_SetBits(GPIOC, GPIO_Pin_13);
#define LED2ON  GPIO_ResetBits(GPIOC, GPIO_Pin_14);
#define LED2OFF GPIO_SetBits(GPIOC, GPIO_Pin_14);
#define LED3ON  GPIO_ResetBits(GPIOC, GPIO_Pin_15);
#define LED3OFF GPIO_SetBits(GPIOC, GPIO_Pin_15);


#define ADC1_DR_Address    ((u32)0x4001244C)
#define  N   1	     //ÿͨ����50��
#define  M  1	     //Ϊ12��ͨ��


#define di()					NVIC_SETFAULTMASK();
#define ei()					NVIC_RESETFAULTMASK();
#define BIT0	(0x1<<0)
#define BIT1	(0x1<<1)
#define BIT2	(0x1<<2)
#define BIT3	(0x1<<3)
#define BIT4	(0x1<<4)
#define BIT5	(0x1<<5)
#define BIT6	(0x1<<6)
#define BIT7	(0x1<<7)
#define BIT8	(0x1<<8)
#define BIT9	(0x1<<9)
#define BIT10	(0x1<<10)
#define BIT11	(0x1<<11)
#define BIT12	(0x1<<12)
#define BIT13	(0x1<<13)
#define BIT14	(0x1<<14)
#define BIT15	(0x1<<15)
#define BIT16	(0x1<<16)
#define BIT17	(0x1<<17)
#define BIT18	(0x1<<18)
#define BIT19	(0x1<<19)
#define BIT20	(0x1<<20)
#define BIT21	(0x1<<21)
#define BIT22	(0x1<<22)
#define BIT23	(0x1<<23)
#define BIT24	(0x1<<24)
#define BIT25	(0x1<<25)
#define BIT26	(0x1<<26)
#define BIT27	(0x1<<27)
#define BIT28	(0x1<<28)
#define BIT29	(0x1<<29)
#define BIT30	(0x1<<30)
#define BIT31	((unsigned int)0x1<<31)

#define T2_Prescaler_Value				48   //1us	����ֵ��1
#define T2_ClockDivision_Value			0x0	 //ʱ��ָ�

#define T4_Prescaler_Value				15 //1ms   ����ֵ��1
#define T4_ClockDivision_Value			0x0	 //ʱ��ָ�

#define T3_Prescaler_Value				43 //1us    ����ֵ��1
#define T3_ClockDivision_Value			0x0	 //ʱ��ָ�	

#define GPIO_LED                   GPIOF    
#define RCC_APB2Periph_GPIO_LED    RCC_APB2Periph_GPIOF

#define RECV_BUF_CLOSE_SIZE	 30



/*FLASH��ַ�ռ����*/
#define ADC1_DR_Address    ((u32)0x4001244C)
#define BASE_PTR_ROM						0x8010000
#define FLASH_PAGE_SIZE						(1*1024)
#define	AUTO_BOOT_ADDR	0X8000000

//void __MSR_MSP(u32 TopOfMainStack);



#define BOOTSTARTADRESS						BASE_PTR_ROM
#define BOOT_SIZE							(16*1024)
#define BOOT_START_SECTOR					0
#define BOOT_END_SECTOR						(BOOT_START_SECTOR + BOOT_SIZE / FLASH_PAGE_SIZE - 1)
#define USER_START_SECTOR					0//(BOOT_END_SECTOR + 1)
#define USERPROGRAMME_SIZE					(44*1024)
#define USER_END_SECTOR						(USER_START_SECTOR + USERPROGRAMME_SIZE / FLASH_PAGE_SIZE - 1)

#define eeprom1_start_block					(USER_END_SECTOR + 1)
#define eeprom2_start_block					(eeprom1_start_block + 1)
#define eeprom1_start_address				(BASE_PTR_ROM + eeprom1_start_block*FLASH_PAGE_SIZE)
#define eeprom2_start_address				(BASE_PTR_ROM + eeprom2_start_block*FLASH_PAGE_SIZE)
#define eeprom1_flg_address					(eeprom1_start_address + FLASH_PAGE_SIZE - 2)
#define eeprom2_flg_address					(eeprom2_start_address + FLASH_PAGE_SIZE - 2)
#define eeprom_size							(FLASH_PAGE_SIZE - 2)




//RAM�ڴ����--һ��10k
#define BASE_PTR_RAM				        0x20000000
#define END_PTR_RAM							0x20002800
//RW ZI��6k
#define END_PTR_RWZIDATA					(0x20001800 - 1)
#define START_PTR_USER						(END_PTR_RWZIDATA + 1)
//485���ջ�����1k
#define RS485_LEN_PTR_INBUFF					(DWORD)(1*1024)
#define RS485_START_PTR_INBUFF					START_PTR_USER

#define RS485_END_PTR_INBUFF					(START_PTR_USER + RS485_LEN_PTR_INBUFF - 1)
//���ڽ��ջ�����1K
#define RS232_LEN_PTR_INBUFF				(DWORD)(1*1024)
#define RS232_START_PTR_INBUFF				(RS485_END_PTR_INBUFF + 1)
#define RS232_END_PTR_INBUFF				(RS232_START_PTR_INBUFF + RS232_LEN_PTR_INBUFF - 1)

//����1k
#define START_AD_DATA						(RS232_END_PTR_INBUFF + 1)//ad
#define MAXLEN_AD_CHANNEL					8
#define END_AD_DATA							(START_AD_DATA + MAXLEN_AD_CHANNEL -1)



#define BOOTINFOADDRESSOFFSET	          0x4f00                           //����������Ϣ������ַƫ��

#define BOOTINFOADDRESS						(LPSTR)(BASE_PTR_RAM + BOOTINFOADDRESSOFFSET)//����������Ϣ����

#define BANK1_WRITE_START_ADDR  ((uint32_t)0x08008000)
#define BANK1_WRITE_END_ADDR    ((uint32_t)0x08008800)
#define BOARDADDRFLASH  0x0801f000


#define BOOTINFOADDRESS_test  ((uint32_t)0x0803fc00)

void HardwareInit(void);
void LedArray(UINT16 RLedState, UINT16 GLedState);


void Start485Tx(word flag);
void StartTxUsart3(word flag);
void StartRxUsart3(word flag);
UINT16 ReadSdSensor(void);
UINT16 ReadShSensor(void);
void Delayms(UINT16 cnt);
void ShowAddrLed(UINT8 addr);
void KeySetAddr(void);
UINT32 WriteDataToFlash(UINT32 Faddr, UINT32 Fdata);
UINT32 ReadFlastData(UINT32 Faddr);
void ReadSdSnr(void);
void ReadShSnr(void);
void Timer2Start(WORD time,word flag);
void Timer3Start(WORD time,word flag);
void Timer4Start(WORD time,word flag);
void filter(void);
void Ledshow(void);
void U32ToString(UINT32 Dword, char *Buffer);
void stringpringf(UINT32 charstring,UINT32 charstring1);
void stringpringfarray(vu16 *charstring);
void HardwareInit1(void);
void Dac1_Set_Vol(u16 vol);
void Dac1_Set_Vol1(u16 vol);
u16 Dac1_Get_Vol(void);
void Mavlink_app(void);
void CloseTim(u8 num);
void Rs485_TX_Control(UINT8 Control);
void can_tx(u8 Data1,u8 Data2,u8 Data3);
void Can_Handle(CanRxMsg CanData);
void CAN_INIT1(u8 Can_Speed);
void IWDG_Feed(void);
void Motor_Run(u8 Motor_Enable, u16 Motor0_Volt, u16 Motor1_Volt);
#define LED1_ON GPIO_SetBits(GPIOA, GPIO_Pin_3);GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define LED2_ON GPIO_SetBits(GPIOA, GPIO_Pin_3);GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define LED3_ON GPIO_SetBits(GPIOA, GPIO_Pin_3);GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define LED4_ON GPIO_SetBits(GPIOA, GPIO_Pin_3);GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define LED5_ON GPIO_SetBits(GPIOA, GPIO_Pin_4);GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define LED6_ON GPIO_SetBits(GPIOA, GPIO_Pin_4);GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define LED7_ON GPIO_SetBits(GPIOA, GPIO_Pin_4);GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define LED8_ON GPIO_SetBits(GPIOA, GPIO_Pin_4);GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define LED9_ON GPIO_SetBits(GPIOA, GPIO_Pin_5);GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define LED10_ON GPIO_SetBits(GPIOA, GPIO_Pin_5);GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define LED11_ON GPIO_SetBits(GPIOA, GPIO_Pin_5);GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define LED12_ON GPIO_SetBits(GPIOA, GPIO_Pin_5);GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define LED13_ON GPIO_SetBits(GPIOA, GPIO_Pin_6);GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define LED14_ON GPIO_SetBits(GPIOA, GPIO_Pin_6);GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define LED15_ON GPIO_SetBits(GPIOA, GPIO_Pin_6);GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define LED16_ON GPIO_SetBits(GPIOA, GPIO_Pin_6);GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define LED17_ON GPIO_SetBits(GPIOA, GPIO_Pin_7);GPIO_ResetBits(GPIOC, GPIO_Pin_6)
#define LED18_ON GPIO_SetBits(GPIOA, GPIO_Pin_7);GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define LED19_ON GPIO_SetBits(GPIOA, GPIO_Pin_7);GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define LED20_ON GPIO_SetBits(GPIOA, GPIO_Pin_7);GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define LED_DISABLE (GPIO_ResetBits(GPIOA, GPIO_Pin_3) GPIO_SetBits(GPIOC, GPIO_Pin_6) GPIO_ResetBits(GPIOA, GPIO_Pin_4) GPIO_SetBits(GPIOC, GPIO_Pin_7) GPIO_ResetBits(GPIOA, GPIO_Pin_5) GPIO_SetBits(GPIOC, GPIO_Pin_8) GPIO_ResetBits(GPIOA, GPIO_Pin_6) GPIO_SetBits(GPIOC, GPIO_Pin_9) GPIO_ResetBits(GPIOA, GPIO_Pin_7))

#define PLED1_ON GPIO_ResetBits(GPIOC, GPIO_Pin_9)
#define PLED2_ON GPIO_ResetBits(GPIOC, GPIO_Pin_8)
#define PLED3_ON GPIO_ResetBits(GPIOC, GPIO_Pin_7)
#define PLED4_ON GPIO_ResetBits(GPIOC, GPIO_Pin_6)

#define PLED1_OFF GPIO_SetBits(GPIOC, GPIO_Pin_9)
#define PLED2_OFF GPIO_SetBits(GPIOC, GPIO_Pin_8)
#define PLED3_OFF GPIO_SetBits(GPIOC, GPIO_Pin_7)
#define PLED4_OFF GPIO_SetBits(GPIOC, GPIO_Pin_6)

#define NLED1_ON GPIO_SetBits(GPIOA, GPIO_Pin_3)
#define NLED2_ON GPIO_SetBits(GPIOA, GPIO_Pin_4)
#define NLED3_ON GPIO_SetBits(GPIOA, GPIO_Pin_5)
#define NLED4_ON GPIO_SetBits(GPIOA, GPIO_Pin_6)
#define NLED5_ON GPIO_SetBits(GPIOA, GPIO_Pin_7)

#define NLED1_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_3)
#define NLED2_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define NLED3_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_5)
#define NLED4_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_6)
#define NLED5_OFF GPIO_ResetBits(GPIOA, GPIO_Pin_7)


#define SH1_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_8)
#define SH2_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_9)
#define SH3_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12)
#define SH4_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)
#define SH5_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15)
#define SH6_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0)
#define SH7_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)
#define SH8_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)
#define SH9_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)
#define SH10_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)
#define SH11_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5)


/***********/

#define Power_Error    		 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)
#define Low_Volt_Error  	 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)
#define Over_Temperature   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)


#define Sensor_Hw1  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_3)
#define Sensor_Hw2  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_6)
#define Sensor_SJ   GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)

#define Sensor_ZF   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)
#define Sensor_Hall GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)

#define IO_Auto_Water   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
#define IO_Rtl      GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)


#define Led_Off    	GPIO_SetBits(GPIOC, GPIO_Pin_13)
#define Led_On    	GPIO_ResetBits(GPIOC, GPIO_Pin_13)
#define Rope_long_to_hall  1050/4

//#define Sonar_Tiger GPIO_ResetBits(GPIOA, GPIO_Pin_1);Delayms(2);GPIO_SetBits(GPIOA, GPIO_Pin_1)

#define Fetch_Water_End   GPIO_ResetBits(GPIOB, GPIO_Pin_10);GPIO_ResetBits(GPIOA, GPIO_Pin_6)
#define Fetch_Water_Ready GPIO_SetBits(GPIOB, GPIO_Pin_10);GPIO_SetBits(GPIOA, GPIO_Pin_6)
/******************/




#define SD1_SIG GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define SD2_SIG GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)
#define SD3_SIG GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_2)
#define SD4_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_11)
#define SD5_SIG GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_10)
#define SD6_SIG GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11)
#define SD7_SIG GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_12)
#define SD8_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)
#define SD9_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define SD10_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)
#define SD11_SIG GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)


#define KEY1_SIG GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_2)


#define SHOWADDR0 GPIO_SetBits(GPIOC, GPIO_Pin_13); GPIO_SetBits(GPIOC, GPIO_Pin_14)
#define SHOWADDR1 GPIO_ResetBits(GPIOC, GPIO_Pin_13); GPIO_SetBits(GPIOC, GPIO_Pin_14)
#define SHOWADDR2 GPIO_SetBits(GPIOC, GPIO_Pin_13); GPIO_ResetBits(GPIOC, GPIO_Pin_14)
#define SHOWADDR3 GPIO_ResetBits(GPIOC, GPIO_Pin_13); GPIO_ResetBits(GPIOC, GPIO_Pin_14)


#define SHOWSETLEDOFF  GPIO_ResetBits(GPIOC, GPIO_Pin_13)
#define SHOWSETLEDON GPIO_SetBits(GPIOC, GPIO_Pin_13)

#define SHOWADDLEDOFF  GPIO_ResetBits(GPIOC, GPIO_Pin_14)
#define SHOWADDLEDON  GPIO_ResetBits(GPIOC, GPIO_Pin_14)


#define RS485ENABLE GPIO_ResetBits(GPIOA, GPIO_Pin_8)
#define RS485DISABLE GPIO_SetBits(GPIOA, GPIO_Pin_8)












#define RESET_ERROR GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)
#define MOTOR_HW GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0)
#define MOTOR_HALL GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_1)
#define MOTOR_SPEED GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_11)
#define E_P_MATER GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_12)

#define MATER_MODE (GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)<<1) | (GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_2))



#define MATER_HW GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_10)
#define CLOSE_CNT GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_15)


#define CONNECT2 GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_7)

#define CONNECT1_H GPIO_SetBits(GPIOC,GPIO_Pin_4)
#define CONNECT1_L GPIO_ResetBits(GPIOC,GPIO_Pin_4)

#define MOTOR0_DIR_B GPIO_SetBits(GPIOC,GPIO_Pin_3)
#define MOTOR0_DIR_F GPIO_ResetBits(GPIOC,GPIO_Pin_3)
#define MOTOR1_DIR_B GPIO_SetBits(GPIOC,GPIO_Pin_15)
#define MOTOR1_DIR_F GPIO_ResetBits(GPIOC,GPIO_Pin_15)

#define MOTOR_2_4_MODE   GPIO_ResetBits(GPIOA,GPIO_Pin_3);GPIO_SetBits(GPIOC,GPIO_Pin_2);GPIO_SetBits(GPIOC,GPIO_Pin_14)
#define MOTOR_1_MODE GPIO_SetBits(GPIOA,GPIO_Pin_3);GPIO_SetBits(GPIOC,GPIO_Pin_2);GPIO_SetBits(GPIOC,GPIO_Pin_14)


//#define MOTOR_1_MODE   GPIO_ResetBits(GPIOA,GPIO_Pin_3);GPIO_ResetBits(GPIOC,GPIO_Pin_2);GPIO_ResetBits(GPIOC,GPIO_Pin_14)
//#define MOTOR_2_4_MODE GPIO_ResetBits(GPIOA,GPIO_Pin_3);GPIO_ResetBits(GPIOC,GPIO_Pin_2);GPIO_ResetBits(GPIOC,GPIO_Pin_14)





#define MOTOR_L_MODE   GPIO_ResetBits(GPIOA,GPIO_Pin_3);GPIO_ResetBits(GPIOC,GPIO_Pin_2);GPIO_ResetBits(GPIOC,GPIO_Pin_14)
#define MOTOR_H_MODE GPIO_SetBits(GPIOA,GPIO_Pin_3);GPIO_SetBits(GPIOC,GPIO_Pin_2);GPIO_SetBits(GPIOC,GPIO_Pin_14)


#define MOTOR0_MODE_H GPIO_SetBits(GPIOA,GPIO_Pin_3)
#define MOTOR0_MODE_L GPIO_ResetBits(GPIOA,GPIO_Pin_3)

#define MOTOR1_MODE_H GPIO_SetBits(GPIOC,GPIO_Pin_14)
#define MOTOR1_MODE_L GPIO_ResetBits(GPIOC,GPIO_Pin_14)


#define MOTOR_SLEEP_H GPIO_SetBits(GPIOC,GPIO_Pin_1)
#define MOTOR_SLEEP_L GPIO_ResetBits(GPIOC,GPIO_Pin_1)


#define MOTOR_ENABLE  GPIO_ResetBits(GPIOC,GPIO_Pin_1)
#define MOTOR_DISABLE GPIO_SetBits(GPIOC,GPIO_Pin_1)


#define MOTOR0_RESET_H GPIO_SetBits(GPIOA,GPIO_Pin_6)
#define MOTOR0_RESET_L GPIO_ResetBits(GPIOA,GPIO_Pin_6)

#define MOTOR1_RESET_H GPIO_SetBits(GPIOC,GPIO_Pin_0)
#define MOTOR1_RESET_L GPIO_ResetBits(GPIOC,GPIO_Pin_0)


#define ERROR_LED_Y_ON GPIO_ResetBits(GPIOB,GPIO_Pin_4)
#define ERROR_LED_R_ON GPIO_ResetBits(GPIOB,GPIO_Pin_5)
#define ERROR_LED_Y_OFF GPIO_SetBits(GPIOB,GPIO_Pin_4)
#define ERROR_LED_R_OFF GPIO_SetBits(GPIOB,GPIO_Pin_5)




#define ADDRESS1 1
#define ADDRESS2 2
#define ADDRESS3 3
#define ADDRESS4 4
#define DefualtBoardAddr 5

#define SOFTREVISION1 00
#define SOFTREVISION2 01
#define SOFTYEAR  13
#define SOFTMONTH 07 
#define SOFTDAY   12 


#define HARDREVISION1 00
#define HARDREVISION2 01
#define HARDYEAR  13
#define HARDMONTH 07 
#define HARDDAY   12 


#define SLAVEADDR 0x00
#define DATALEN   0x01
#define HOSTADDR  0x02
#define CMDID     0x03
#define DATA      0x04
#define CRCFAM    0x05
#define CRCFAM1    0x06
#define HOSTADDRESS 0x55
#define UART1RECEIVE 01
#define UART2RECEIVE 02
#define UART3RECEIVE 03



#define BOOTSTATE1 0x00
#define BOOTSTATE2 0x01
#define BOOTSTATE3 0x02


#endif
/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
