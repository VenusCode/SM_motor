/******************** ��ʢ���ӹ����� ********************
 * �ļ���  ��main.c
 * ����    ������ͬ����MINI�����ش˳���󣬰���һ�������ϵİ��������Ե�����һ������
 *           �϶�Ӧ��LED���������Ӳ������ӡ�         
 * ʵ��ƽ̨��MINI STM32������ ����STM32F103C8T6
 * ��汾  ��ST3.0.0   																										  
 * �Ա��꣺http://shop66177872.taobao.com
*********************************************************/
#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_dma.h"
#include "can.h"
#include "led.h"
#include "hardware.h"
#include <stdbool.h>

#include <stdbool.h>
#include <stdio.h>
#include "misc.h"
#include "math.h"


void Dalayms(UINT16 cnt);

u16 crc_accumulate(u8 *sss ,u16 len, u8 crc_extra);
void USART_SendData_1(uint8_t ch);
uint8_t JumpToApplication(uint32_t Addr);
void WritePowerONState(void);
void NVIC_GenerateSystemReset(void);
void WritePowerONState(void);
uint32_t Cal_checksum(uint16_t * addrstart, uint16_t * addrend);
void Uart_App(void);

void WritePowerOFFState(void);
#define   PAKEHEAD1	 0x00
#define	  PAKELEN1	 0x01
#define	  PAKENO1	 0x02
#define	  SYSID1		 0x03
#define	  PLANID1	 0x04
#define	  CMDID1		 0x05
#define	  PAKEDATA1	 0x06
#define	  PAKECRC11	 0x07
#define	  PAKECRC21	 0x08

#define PAKE_HEAD 0xfe
#define SYSID 0x01
#define DEVID 0x221


RCC_ClocksTypeDef  rcc_clocks;

void Delay(vu32 nCount)
{
  for(; nCount != 0; nCount--);
}



uint32_t Cal_checksum12(uint32_t * addrstart, uint32_t * addrend)
{
	uint32_t * addr;
	uint32_t checksum = 0;

	addr = addrstart;
	while( addr <= addrend )
	{
		checksum += *addr++;
	}	
	return checksum;
}

u32 checksum = 0;
#define PROGRAM_ADDR_START 0x08004000
#define USER_PROGRAMME_SIZE					(111*1024)
#define PROGRAM_ADDR_END 					(PROGRAM_ADDR_START + USER_PROGRAMME_SIZE - 1 - 0x20)//
int main(void)
{   
	//SystemInit(); //����ϵͳʱ��Ϊ72M
	//AD_IO_Init();	  //�����ܽų�ʼ��

	HardwareInit();
//WritePowerOFFState();

	RCC_GetClocksFreq(&rcc_clocks);	/* get the main clock	*/

//	checksum = Cal_checksum12((uint32_t *) PROGRAM_ADDR_START,(uint32_t *) PROGRAM_ADDR_END);	
//	WriteDataToFlash(BOOTINFOADDRESS_test + 20,checksum);
//	
//	checksum = *(uint16_t *)(BOOTINFOADDRESS_test + 20);
//	
	
//	
//	TxMessage.StdId= 0x1f;	//��׼��ʶ��Ϊ0x00
//	TxMessage.IDE=CAN_ID_STD;//ʹ�ñ�׼��ʶ��
//	TxMessage.RTR=CAN_RTR_DATA;//Ϊ����֡
//	
//	TxMessage.DLC = 3;	//	��Ϣ�����ݳ���Ϊ3���ֽ�
//	TxMessage.Data[0] = 0xff; //��һ���ֽ�����
//	TxMessage.Data[1] = checksum % 256; //�ڶ����ֽ����� 
//	TxMessage.Data[2] = checksum / 256; //�ڶ����ֽ����� 
//	CAN_Transmit(CAN1,&TxMessage); //��������
//	
//	
	
//	printf("checksum is %x",checksum);
	
//	if(Broad_ID < 0x221 || Broad_ID > 0x228)
//	{
//		Broad_ID = DEVID;
//		WriteDataToFlash(BOOTINFOADDRESS_test + 16,Broad_ID);
//	}
//	Send_Alarm_to_IPC();
//Motor_Run(0,0,0);
 	while(1)
  {

		
		//IWDG_Feed();
		Uart_App();
		//Motor_Run(1,1,2300,2300);
  }
}


extern u8 ReceiveIndex;
extern u8 Rx485in[256];
extern uint8_t OutPut_Enable;
extern uint16_t OutPut_Num;
extern UINT32 Time_Cnt_mS;
u8 Uart_State_Flag = 0;
u8 UartIndex = 0;
u8 UartState;
u32 Uart_State_Counter;

u8 Data_Lth = 0;
u8 Uart_Data[10];
u32 Uart_Data_Hex = 0;


void Send_OutPut_Num(uint8_t Num, uint8_t Enable)
{
//  OutPut_Enable = Enable;
//	OutPut_Num = Num;
}

uint32_t Arc_2_Hex(u8* Data, u8 Lth)
{
	u8 i = 0;
	uint32_t Hex_Data = 0;
	for(i = 0; i < Lth; i ++)
	{
		
		Hex_Data = Hex_Data * 10 + (*Data - '0');
		Data ++;
		
	}
	
	return Hex_Data;
	
}

void Uart_App(void)
{
	if(Uart_State_Flag == 1)
	{
		if((Time_Cnt_mS - Uart_State_Counter) > 10)
		{
			//Motor_Run(1,1,2300,2300);
			UartState = SLAVEADDR;
			Uart_Data_Hex = Arc_2_Hex(Uart_Data,Data_Lth);
			Send_OutPut_Num(Uart_Data_Hex, 1);
			Uart_State_Flag = 0;
			Data_Lth = 0;			
			
		}
	}

	if(UartIndex != ReceiveIndex)//������������
	{
		if(Uart_State_Flag == 0)
		{
			Uart_State_Counter = Time_Cnt_mS;
			Uart_State_Flag = 1;
		}
		if(Rx485in[UartIndex] >= '0' && Rx485in[UartIndex] <= '9')
		Uart_Data[Data_Lth] = Rx485in[UartIndex];
		Data_Lth ++;
		UartIndex ++;
	}
}

void WritePowerONState(void)
{	

	WriteDataToFlash(BOOTINFOADDRESS_test,'G');
	WriteDataToFlash(BOOTINFOADDRESS_test + 4,'Y');
	
	WriteDataToFlash(BOOTINFOADDRESS_test + 8,'D');
	WriteDataToFlash(BOOTINFOADDRESS_test + 12,'Z');
	
}
void WritePowerOFFState(void)
{	

	WriteDataToFlash(BOOTINFOADDRESS_test,0xff);
	WriteDataToFlash(BOOTINFOADDRESS_test + 4,0xff);
	
	WriteDataToFlash(BOOTINFOADDRESS_test + 8,0xff);
	WriteDataToFlash(BOOTINFOADDRESS_test + 12,0xff);

}



void NVIC_GenerateSystemReset(void)
{
	
	NVIC_SETFAULTMASK();
	
  SCB->AIRCR = 0x05FA0000 | (u32)0x04;

}



typedef  void (*pFunction)(void);
uint8_t JumpToApplication(uint32_t Addr)
{
	pFunction Jump_To_Application;
	__IO uint32_t JumpAddress; 
	/* Test if user code is programmed starting from address "ApplicationAddress" */
	if (((*(__IO uint32_t*)Addr) & 0x2FFE0000 ) == 0x20000000)
	{ 
	  /* Jump to user application */
	  JumpAddress = *(__IO uint32_t*) (Addr + 4);
	  Jump_To_Application = (pFunction) JumpAddress; 
	  /* Initialize user application's Stack Pointer */
	  //__set_MSP(*(__IO uint32_t*) Addr);
	  Jump_To_Application();
	}
//	TimeOutFlag=0xFF;
	return 1;
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/


